package com.example.magicgarden

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Looper
import android.text.Editable
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.gms.location.*
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.navigation.NavigationView
import com.squareup.picasso.Picasso
import org.json.JSONObject

class WeatherActivity : AppCompatActivity() {

    private var weatherUrl = ""
    private var currentUrl = ""
    private var apiId = "aed565df1caa428290d15f772e5d667b"
    private val iconUrl = "https://www.weatherbit.io/static/img/icons/"
    private var lastLocation = ""

    private lateinit var weather : MenuItem

    private lateinit var locationText : EditText

    private lateinit var iconToday : ImageView
    private lateinit var tempToday : TextView

    private lateinit var icon1 : ImageView
    private lateinit var icon2 : ImageView
    private lateinit var icon3 : ImageView
    private lateinit var icon4 : ImageView

    private lateinit var text1 : TextView
    private lateinit var text2 : TextView
    private lateinit var text3 : TextView
    private lateinit var text4 : TextView

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weather)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        startLocalization()

        val drawerLayout = findViewById<DrawerLayout>(R.id.drawerLayoutWeather)
        val topAppBar = findViewById<MaterialToolbar>(R.id.weatherAppBar)
        val navView = findViewById<NavigationView>(R.id.navViewWeat)
        val menu = navView.menu
        val ownGarden = menu.getItem(0)
        val atlas = menu.getItem(1)
        weather = menu.getItem(2)
        val logout = menu.getItem(3)

        val refresh = findViewById<Button>(R.id.refreshButton)
        val locate = findViewById<Button>(R.id.locationButton)
        locationText = findViewById(R.id.locationText)

        iconToday = findViewById(R.id.weatherIconToday)
        tempToday = findViewById(R.id.tempToday)

        icon1 = findViewById(R.id.weatherIcon1)
        icon2 = findViewById(R.id.weatherIcon2)
        icon3 = findViewById(R.id.weatherIcon3)
        icon4 = findViewById(R.id.weatherIcon4)

        text1 = findViewById(R.id.weatherText1)
        text2 = findViewById(R.id.weatherText2)
        text3 = findViewById(R.id.weatherText3)
        text4 = findViewById(R.id.weatherText4)

        val username = intent.extras?.getString("username")

        refresh.setOnClickListener {
            getWeather()
        }

        locate.setOnClickListener {
            obtainLocation()
        }

        topAppBar.title = "Pogoda"

        topAppBar.setNavigationOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }

        logout.setOnMenuItemClickListener {
            val i = Intent(this, LoginActivity::class.java)
            startActivity(i)
            finish()
            true
        }

        ownGarden.setOnMenuItemClickListener {
            val i = Intent(this, MainActivity::class.java)
            i.putExtra("username", username)
            startActivity(i)
            true
        }

        atlas.setOnMenuItemClickListener {
            val i = Intent(this, AtlasActivity::class.java)
            i.putExtra("username", username)
            i.putExtra("logged", true)
            startActivity(i)
            true
        }

        weather.setOnMenuItemClickListener {
            val i = Intent(this, WeatherActivity::class.java)
            i.putExtra("username", username)
            startActivity(i)
            true
        }

    }

    override fun onResume() {
        super.onResume()
        weather.isChecked = true
    }

    private fun obtainLocation() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this@WeatherActivity, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 100)
            ActivityCompat.requestPermissions(this@WeatherActivity, arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 101)
            return
        }
        fusedLocationClient.lastLocation.addOnSuccessListener {
            location: Location? ->
            weatherUrl = "https://api.weatherbit.io/v2.0/forecast/daily?" + "lat=" + location?.latitude + "&lon=" + location?.longitude + "&key=" + apiId + "&lang=pl"
            currentUrl = "https://api.weatherbit.io/v2.0/current?" + "lat=" + location?.latitude + "&lon=" + location?.longitude + "&key=" + apiId + "&lang=pl"
            val geocoder = Geocoder(this)
            locationText.setText(geocoder.getFromLocation(location!!.latitude, location.longitude, 1)[0].locality)
            lastLocation = locationText.text.toString()
        }

    }

    private fun getWeather() {

        if (locationText.text.toString().isBlank()) {
            return
        }

        if (lastLocation != locationText.text.toString()) {
            val geocoder = Geocoder(this)
            val address = geocoder.getFromLocationName(locationText.text.toString(), 1)[0]
            weatherUrl = "https://api.weatherbit.io/v2.0/forecast/daily?" + "lat=" + address.latitude + "&lon=" + address.longitude + "&key=" + apiId + "&lang=pl"
            currentUrl = "https://api.weatherbit.io/v2.0/current?" + "lat=" + address.latitude + "&lon=" + address.longitude + "&key=" + apiId + "&lang=pl"
        }

        val queue = Volley.newRequestQueue(this)
        val url1 : String = currentUrl
        val url2 : String = weatherUrl

        val stringReq = StringRequest(url2, { response ->
            val obj = JSONObject(response)
            val arr = obj.getJSONArray("data")
            var obj2 = arr.getJSONObject(1)
            var date = obj2.getString("valid_date")
            text1.text = date.substring(8) + "." +date.substring(5,7) + "\n" + obj2.getString("temp") + "°C" + "\n" + obj2.getString("pop") + "%"
            Picasso.get().load(iconUrl + obj2.getJSONObject("weather").getString("icon") + ".png").fit().centerCrop().into(icon1)
            obj2 = arr.getJSONObject(2)
            date = obj2.getString("valid_date")
            text2.text = date.substring(8) + "." +date.substring(5,7) + "\n" + obj2.getString("temp") + "°C" + "\n" + obj2.getString("pop")+ "%"
            Picasso.get().load(iconUrl + obj2.getJSONObject("weather").getString("icon") + ".png").fit().centerCrop().into(icon2)
            obj2 = arr.getJSONObject(3)
            date = obj2.getString("valid_date")
            text3.text = date.substring(8) + "." +date.substring(5,7) + "\n" + obj2.getString("temp") + "°C" + "\n" + obj2.getString("pop")+ "%"
            Picasso.get().load(iconUrl + obj2.getJSONObject("weather").getString("icon") + ".png").fit().centerCrop().into(icon3)
            obj2 = arr.getJSONObject(4)
            date = obj2.getString("valid_date")
            text4.text = date.substring(8) + "." +date.substring(5,7) + "\n" + obj2.getString("temp") + "°C" + "\n" + obj2.getString("pop")+ "%"
            Picasso.get().load(iconUrl + obj2.getJSONObject("weather").getString("icon") + ".png").fit().centerCrop().into(icon4)
        },
        {
            text1.text = ""
            text2.text = ""
            text3.text = ""
            text4.text = ""
        })
        val currReq = StringRequest(url1, { response ->
            val obj = JSONObject(response)
            val arr = obj.getJSONArray("data")
            var obj2 = arr.getJSONObject(0)
            tempToday.text = obj2.getString("temp") + "°C"
            Picasso.get().load(iconUrl + obj2.getJSONObject("weather").getString("icon") + ".png").fit().centerCrop().into(iconToday)
        },
            {
                tempToday.text = "Błąd ładowania pogody :("
            })
        queue.add(currReq)
        queue.add(stringReq)
    }

    private fun startLocalization() {
        var mLocationRequest = LocationRequest.create()
        mLocationRequest.interval = 1000
        mLocationRequest.fastestInterval = 500
        mLocationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                for (location in locationResult.locations) {
                    if (location != null) {
                        return
                    }
                }
            }
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                101
            )
        }
        LocationServices.getFusedLocationProviderClient(this).requestLocationUpdates(
            mLocationRequest, locationCallback, Looper.getMainLooper())
    }

}