package com.example.magicgarden.Modal

data class Flower(val name : String? = null,
                  val flowering_period : String? = null,
                  val light_amount : String? = null,
                  val description : String? = null,
                  val watering : String? = null,
                  val picture_url : String? = null)