package com.example.magicgarden.DB

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.magicgarden.Modal.InnerFlower

class DBHelper(context: Context): SQLiteOpenHelper(context,DATABASE_NAME,
    null, DATABASE_VER) {
    companion object {
        private val DATABASE_VER = 2
        private val DATABASE_NAME = "EDMTDB.db"
        //Table
        private val TABLE_NAME = "Flowers"
        private val COL_NAME = "Name"
        private val COL_DESCRIPTION = "Description"
        private val COL_LIGHT = "Light_amount"
        private val COL_FLOWERING = "Flowering_period"
        private val COL_WATERING = "Watering"
        private val COL_PICTURE = "Picture_url"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val CREATE_TABLE_QUERY = ("CREATE TABLE $TABLE_NAME ($COL_NAME TEXT PRIMARY KEY, $COL_DESCRIPTION TEXT, $COL_LIGHT TEXT," +
                " $COL_FLOWERING TEXT, $COL_WATERING TEXT, $COL_PICTURE TEXT)")
        db!!.execSQL(CREATE_TABLE_QUERY)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db!!.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db!!)
    }

    val allFlowers:List<InnerFlower>
        get(){
            val listFlowers = ArrayList<InnerFlower>()
            val selectQuery = "SELECT * FROM $TABLE_NAME ORDER BY $COL_NAME"
            val db = this.writableDatabase
            val cursor =  db.rawQuery(selectQuery, null)
            if(cursor.moveToFirst()){
                do {
                    val flower = InnerFlower()
                    flower.name = cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME))
                    flower.description = cursor.getString(cursor.getColumnIndexOrThrow(COL_DESCRIPTION))
                    flower.light_amount = cursor.getString(cursor.getColumnIndexOrThrow(COL_LIGHT))
                    flower.flowering_period = cursor.getString(cursor.getColumnIndexOrThrow(COL_FLOWERING))
                    flower.watering = cursor.getString(cursor.getColumnIndexOrThrow(COL_WATERING))
                    flower.picture_url = cursor.getString(cursor.getColumnIndexOrThrow(COL_PICTURE))

                    listFlowers.add(flower)
                } while (cursor.moveToNext())
            }
            db.close()
            return listFlowers
        }

    fun addFlower(flower: InnerFlower){
        val db= this.writableDatabase
        val values = ContentValues()
        values.put(COL_NAME, flower.name)
        values.put(COL_DESCRIPTION, flower.description)
        values.put(COL_LIGHT, flower.light_amount)
        values.put(COL_FLOWERING, flower.flowering_period)
        values.put(COL_WATERING, flower.watering)
        values.put(COL_PICTURE, flower.picture_url)

        db.insert(TABLE_NAME, null, values)
        db.close()
    }

    fun getFlower(name:String): String {
        val selectQuery = "SELECT * FROM $TABLE_NAME WHERE $COL_NAME = '$name'"
        val db = this.writableDatabase
        val cursor = db.rawQuery(selectQuery, null)
        cursor.moveToFirst()
        val dane = cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME)) + ":" +
                cursor.getString(cursor.getColumnIndexOrThrow(COL_DESCRIPTION)) + ":" +
                cursor.getString(cursor.getColumnIndexOrThrow(COL_LIGHT)) + ":" +
                cursor.getString(cursor.getColumnIndexOrThrow(COL_FLOWERING)) + ":" +
                cursor.getString(cursor.getColumnIndexOrThrow(COL_WATERING)) + ":" +
                cursor.getString(cursor.getColumnIndexOrThrow(COL_PICTURE))
        return dane
    }

    fun checkFlower(key:String): Boolean {
        val selectQuery = "SELECT * FROM $TABLE_NAME WHERE $COL_NAME = '$key'"
        val db = this.writableDatabase
        val cursor = db.rawQuery(selectQuery, null)
        if (cursor.moveToFirst()){
            if(key == cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME))) {
                return true
            }
        }
        return false
    }

    fun checkDB(context : Context) : Boolean {
        val db = context.getDatabasePath(DATABASE_NAME)
        return db.exists()
    }

}

