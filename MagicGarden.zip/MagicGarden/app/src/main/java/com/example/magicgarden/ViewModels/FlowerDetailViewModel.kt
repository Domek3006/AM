package com.example.magicgarden.ViewModels

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.magicgarden.DB.DBHelper
import com.example.magicgarden.Modal.InnerFlower
import java.lang.IllegalArgumentException

class FlowerDetailViewModel(private val flowers : List<InnerFlower>) : ViewModel() {
}

class FlowersDetailViewModelFactory(private val context: Context) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FlowersViewModel::class.java)) {
            val db = DBHelper(context)
            return FlowersViewModel(db.allFlowers) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }

}