package com.example.magicgarden.Adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.ListAdapter
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.magicgarden.Modal.InnerFlower
import com.example.magicgarden.R
import com.example.magicgarden.ViewModels.FlowersViewModel
import com.squareup.picasso.Picasso

class RecyclerAdapter(private val onClick: (InnerFlower) -> Unit) : ListAdapter<InnerFlower, RecyclerAdapter.FlowerViewHolder>(FlowerDiffCallback) {
    class FlowerViewHolder(itemView: View, val onClick: (InnerFlower) -> Unit) : RecyclerView.ViewHolder(itemView) {

        private val textView = itemView.findViewById<TextView>(R.id.plantCardText)
        private val imageView = itemView.findViewById<ImageView>(R.id.plantCardImg)
        private var currFlower : InnerFlower? = null

        init {
            itemView.setOnClickListener {
                currFlower?.let {
                    onClick(it)
                }
            }
        }

        fun bind(flower: InnerFlower) {
            currFlower = flower

            textView.text = flower.name
            Picasso.get().load(flower.picture_url).fit().centerCrop().into(imageView)
        }

    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FlowerViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.plant_card, parent, false)
        return FlowerViewHolder(view, onClick)
    }

    override fun onBindViewHolder(holder: FlowerViewHolder, position: Int) {
        val flower = getItem(position)
        holder.bind(flower)
    }

}

object FlowerDiffCallback : DiffUtil.ItemCallback<InnerFlower>() {
    override fun areItemsTheSame(oldItem: InnerFlower, newItem: InnerFlower): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(oldItem: InnerFlower, newItem: InnerFlower): Boolean {
        return oldItem.name == newItem.name
    }
}

