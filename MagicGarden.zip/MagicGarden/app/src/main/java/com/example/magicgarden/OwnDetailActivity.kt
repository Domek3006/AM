package com.example.magicgarden

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.viewModels
import com.example.magicgarden.DB.DBHelper
import com.example.magicgarden.ViewModels.FlowerDetailViewModel
import com.example.magicgarden.ViewModels.FlowersDetailViewModelFactory
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.squareup.picasso.Picasso

class OwnDetailActivity : AppCompatActivity() {
    private val firedb = Firebase.firestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.own_detail)

        var currFlowerName: String? = null
        var username: String? = null

        val flowerName = findViewById<TextView>(R.id.flowerNameOwn)
        val flowerDesc = findViewById<TextView>(R.id.flowerDescriptionOwn)
        val flowerPeriod = findViewById<TextView>(R.id.flowerPeriodOwn)
        val flowerLight = findViewById<TextView>(R.id.flowerLightOwn)
        val flowerWater = findViewById<TextView>(R.id.flowerWaterOwn)
        val flowerImg = findViewById<ImageView>(R.id.flowerImgOwn)
        val addFlower = findViewById<Button>(R.id.removeButtonOwn)
        addFlower.visibility = VISIBLE

        val bundle: Bundle? = intent.extras
        if (bundle != null) {
            currFlowerName = bundle.getString(FLOWER_NAME)
            username = bundle.getString("username")
        }

        fun deleteFlower(username: String, flower: String) {
            val users = firedb.collection("Users")
            users.document(username).update("ownFlowers", FieldValue.arrayRemove(flower))
        }

        currFlowerName?.let {
            val db = DBHelper(this)
            val currFlower = db.getFlower(it)
            val currFlowerData = currFlower.split(":")
            flowerName.text = currFlowerData[0].capitalize()
            flowerDesc.text = currFlowerData[1]
            flowerLight.text = "Ilość światła: " + currFlowerData[2]
            flowerPeriod.text = "Kwitnienie: " + currFlowerData[3]
            flowerWater.text = "Podlewanie: " + currFlowerData[4]
            Picasso.get().load(currFlowerData[5] + ":" + currFlowerData[6]).fit().centerCrop().into(flowerImg)


            addFlower.setOnClickListener {
                deleteFlower(username.toString(), currFlowerName)
                val i = Intent(this, MainActivity::class.java)
                i.putExtra("username", username)
                startActivity(i)
                finish()
            }
        }
    }
}