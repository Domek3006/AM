package com.example.magicgarden

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.magicgarden.DB.DBHelper
import com.example.magicgarden.Modal.InnerFlower
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase


class LoginActivity : AppCompatActivity() {

    private var firedb = Firebase.firestore
    private val db = DBHelper(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val register_button = findViewById<Button>(R.id.RegisterButton)
        val login_button = findViewById<Button>(R.id.LoginButton)
        val username = findViewById<EditText>(R.id.logUsername)
        val passwd = findViewById<EditText>(R.id.logPassword)
        val atlas = findViewById<Button>(R.id.AtlasButton)

        val notFound = Toast.makeText(applicationContext, "Użytkownik nie znaleziony", Toast.LENGTH_LONG)
        val wrongPasswd = Toast.makeText(applicationContext, "Zły login lub hasło", Toast.LENGTH_LONG)
        val success = Toast.makeText(applicationContext, "Zalogowano", Toast.LENGTH_LONG)
        val noInternet = Toast.makeText(applicationContext, "Brak dostępu do Internetu", Toast.LENGTH_LONG)


        login_button.setOnClickListener {
            if (isNetworkAvailable()) {
                val users = firedb.collection("Users")
                if (username.text.toString().trim().isNotEmpty() && passwd.text.toString().trim()
                        .isNotEmpty()
                ) {
                    if (!username.text.matches("^[a-zA-Z0-9]*$".toRegex()) || !passwd.text.matches("^[a-zA-Z0-9]*$".toRegex())) {
                    } else {
                        users.document(username.text.toString()).get()
                            .addOnSuccessListener { document ->
                                if (document.data != null) {
                                    if (document.get("password")
                                            .toString() == passwd.text.toString()
                                    ) {
                                        success.show()
                                        val i = Intent(this, MainActivity::class.java)
                                        i.putExtra("username", username.text.toString())
                                        startActivity(i)
                                        finish()
                                    } else {
                                        wrongPasswd.show()
                                    }
                                } else {
                                    notFound.show()
                                }
                            }
                    }
                }
            } else {
                noInternet.show()
            }
        }

        register_button.setOnClickListener {
            if (isNetworkAvailable()){
                val i = Intent(this, RegisterActivity::class.java)
                startActivity(i)
            } else {
                noInternet.show()
            }
        }

        atlas.setOnClickListener {
            val i = Intent(this, AtlasActivity::class.java)
            i.putExtra("logged", false)
            startActivity(i)
        }

        if (!db.checkDB(this)) {
            val flowers = firedb.collection("Flowers")
            flowers.get().addOnSuccessListener { flower ->
                for (plant in flower) {
                    db.addFlower(
                        InnerFlower(
                            plant.get("nazwa").toString(),
                            plant.get("opis").toString(),
                            plant.get("ilość światła").toString(),
                            plant.get("kwitnienie").toString(),
                            plant.get("podlewanie").toString(),
                            plant.get("zdjęcie").toString()
                        )
                    )
                }

            }
        }

    }

    override fun onBackPressed() {
        finish()
    }

    private fun isNetworkAvailable(): Boolean {
        val connectivityManager =
            getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val capabilities =
            connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)
        if (capabilities != null) {
            if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                return true
            } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                return true
            } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                return true
            }
        }
        return false
    }

}
