package com.example.magicgarden.ViewModels

import android.content.Context
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.magicgarden.DB.DBHelper
import com.example.magicgarden.Modal.InnerFlower
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.lang.IllegalArgumentException

class FlowersViewModel(private val flowers: List<InnerFlower>) : ViewModel() {
    val flowersData = MutableLiveData(flowers)
}

class FlowersViewModelFactory(private val context: Context) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FlowersViewModel::class.java)) {
            val db = DBHelper(context)
            return FlowersViewModel(db.allFlowers) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }

}