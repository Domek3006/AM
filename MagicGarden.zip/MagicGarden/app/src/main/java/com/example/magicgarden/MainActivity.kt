package com.example.magicgarden

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.RecyclerView
import com.example.magicgarden.Adapters.RecyclerAdapter
import com.example.magicgarden.Modal.InnerFlower
import com.example.magicgarden.ViewModels.FlowersViewModel
import com.example.magicgarden.ViewModels.FlowersViewModelFactory
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.navigation.NavigationView
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.util.*
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity() {

    private lateinit var ownGarden : MenuItem
    lateinit var mainAct : Activity
    private val firedb = Firebase.firestore

    private val flowersViewModel by viewModels<FlowersViewModel> {
        FlowersViewModelFactory(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mainAct = this

        val recyclerView = findViewById<RecyclerView>(R.id.plantRecycler)
        val drawerLayout = findViewById<DrawerLayout>(R.id.drawerLayout)
        val topAppBar = findViewById<MaterialToolbar>(R.id.mainAppBar)
        val navView = findViewById<NavigationView>(R.id.navView)
        val menu = navView.menu
        ownGarden = menu.getItem(0)
        val atlas = menu.getItem(1)
        val weather = menu.getItem(2)
        val logout = menu.getItem(3)

        val username = intent.extras?.getString("username")

        fun adapterOnClick(flower: InnerFlower) {
            val intent = Intent(this, OwnDetailActivity::class.java)
            intent.putExtra(FLOWER_NAME, flower.name)
            intent.putExtra("logged", true)
            intent.putExtra("username", username)
            startActivity(intent)
        }

        val recyclerAdapter = RecyclerAdapter { flower -> adapterOnClick(flower) }

        var flowersList = listOf("")
        val users = firedb.collection("Users")
        users.document(username.toString()).get()
            .addOnSuccessListener { document ->
                if (document.data != null ) {
                    flowersList = document.get("ownFlowers").toString().replace("]", "").replace("[","").trim().split(", ")
                    flowersList = flowersList.sorted()
                }
                flowersViewModel.flowersData.observe(this) {
                    it?.let {
                        val newList = ArrayList<InnerFlower>()
                        for (flower in it){
                            if (flower.name.toString() in flowersList) {
                                newList.add(flower)
                            }
                        }
                        recyclerAdapter.submitList(newList as MutableList<InnerFlower>)
                    }
                }
            }

        recyclerView.adapter = recyclerAdapter

        topAppBar.title = "Mój Ogród"

        topAppBar.setNavigationOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }

        logout.setOnMenuItemClickListener {
            val i = Intent(this, LoginActivity::class.java)
            startActivity(i)
            finish()
            true
        }

        ownGarden.setOnMenuItemClickListener {
            val i = Intent(this, MainActivity::class.java)
            i.putExtra("username", username)
            startActivity(i)
            true
        }

        atlas.setOnMenuItemClickListener {
            val i = Intent(this, AtlasActivity::class.java)
            i.putExtra("username", username)
            i.putExtra("logged", true)
            startActivity(i)
            true
        }

        weather.setOnMenuItemClickListener {
            val i = Intent(this, WeatherActivity::class.java)
            i.putExtra("username", username)
            startActivity(i)
            true
        }

    }

    override fun onResume() {
        super.onResume()
        ownGarden.isChecked = true
    }

}