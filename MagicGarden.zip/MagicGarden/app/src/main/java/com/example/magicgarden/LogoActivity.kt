package com.example.magicgarden

import android.content.Intent
import android.graphics.drawable.AnimatedVectorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class LogoActivity : AppCompatActivity() {

    private lateinit var flowerAnimation: AnimatedVectorDrawable

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_logo)

        val windowInsetsController = ViewCompat.getWindowInsetsController(window.decorView) ?: return
        windowInsetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars())

        findViewById<ImageView>(R.id.flowerImage).apply {
            setBackgroundResource(R.drawable.ic_flower_vec)
            flowerAnimation = background as AnimatedVectorDrawable
        }

        val thread = Thread(){
            run{
                flowerAnimation.start()
                Thread.sleep(6000)
            }
            runOnUiThread(){
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                windowInsetsController.show(WindowInsetsCompat.Type.systemBars())
                finish()
            }
        }

        thread.start()
    }
}