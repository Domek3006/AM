package com.example.magicgarden.Modal

class InnerFlower {
    var name: String? = null
    var description: String? = null
    var light_amount: String? = null
    var flowering_period: String? = null
    var watering: String? = null
    var picture_url: String? = null

    constructor() {}

    constructor(name: String, description: String, light_amount: String, flowering_period: String, watering: String, picture_url: String) {
        this.name = name
        this.description = description
        this.light_amount = light_amount
        this.flowering_period = flowering_period
        this.watering = watering
        this.picture_url = picture_url
    }
}