package com.example.magicgarden

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.viewModels
import com.example.magicgarden.DB.DBHelper
import com.example.magicgarden.ViewModels.FlowerDetailViewModel
import com.example.magicgarden.ViewModels.FlowersDetailViewModelFactory
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.squareup.picasso.Picasso

class DetailActivity : AppCompatActivity() {

    private val firedb = Firebase.firestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.plant_detail)

        var currFlowerName: String? = null
        var logged = false
        var username: String? = null

        val bundle: Bundle? = intent.extras
        if (bundle != null) {
            currFlowerName = bundle.getString(FLOWER_NAME)
            logged = bundle.getBoolean("logged")
            username = bundle.getString("username")
        }

        val flowerName = findViewById<TextView>(R.id.flowerName)
        val flowerDesc = findViewById<TextView>(R.id.flowerDescription)
        val flowerPeriod = findViewById<TextView>(R.id.flowerPeriod)
        val flowerLight = findViewById<TextView>(R.id.flowerLight)
        val flowerWater = findViewById<TextView>(R.id.flowerWater)
        val flowerImg = findViewById<ImageView>(R.id.flowerImg)
        val addFlower = findViewById<Button>(R.id.removeButton)
        addFlower.visibility = VISIBLE

        fun addFlower(username: String, flower: String) {
            val users = firedb.collection("Users")
            users.document(username).update("ownFlowers", FieldValue.arrayUnion(flower))
        }
        fun deleteFlower(username: String, flower: String) {
            val users = firedb.collection("Users")
            users.document(username).update("ownFlowers", FieldValue.arrayRemove(flower))
        }

        var onList = false

        var flowersList : List<String>
        val users = firedb.collection("Users")
        users.document(username.toString()).get()
            .addOnSuccessListener { document ->
                if (document.data != null ) {
                    flowersList = document.get("ownFlowers").toString().replace("]", "").replace("[","").trim().split(",")
                    if (currFlowerName.toString() in flowersList) {
                        onList = true
                        if(onList) {
                            addFlower.text = "Usuń z Ogrodu"
                        } else {
                            addFlower.text = "Dodaj do Ogrodu"
                        }
                    }
                }
            }

        currFlowerName?.let {
            val db = DBHelper(this)
            val currFlower = db.getFlower(it)
            val currFlowerData = currFlower.split(":")
            flowerName.text = currFlowerData[0].capitalize()
            flowerDesc.text = currFlowerData[1]
            flowerLight.text = "Ilość światła: " + currFlowerData[2]
            flowerPeriod.text = "Kwitnienie: " + currFlowerData[3]
            flowerWater.text = "Podlewanie: " + currFlowerData[4]
            Picasso.get().load(currFlowerData[5] + ":" + currFlowerData[6]).fit().centerCrop().into(flowerImg)

            if (logged) {
                addFlower.setOnClickListener {
                    if (onList){
                        deleteFlower(username.toString(), currFlowerName)
                        addFlower.text = "Dodaj do Ogrodu"
                        onList = false
                    } else {
                        addFlower(username.toString(), currFlowerName)
                        addFlower.text = "Usuń z Ogrodu"
                        onList = true
                    }
                }
            } else {
                addFlower.visibility = GONE
            }


        }
    }
}