package com.example.magicgarden.Modal

data class User(val username : String? = null, val password : String? = null, val ownFlowers : List<String>? = null)