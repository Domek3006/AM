package com.example.magicgarden

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View.GONE
import androidx.activity.viewModels
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.RecyclerView
import com.example.magicgarden.Adapters.RecyclerAdapter
import com.example.magicgarden.Modal.InnerFlower
import com.example.magicgarden.ViewModels.FlowersViewModel
import com.example.magicgarden.ViewModels.FlowersViewModelFactory
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.navigation.NavigationView
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

const val FLOWER_NAME = "flower name"

class AtlasActivity : AppCompatActivity() {

    private var firedb = Firebase.firestore
    private lateinit var atlas : MenuItem
    private var logged = false
    private val flowersViewModel by viewModels<FlowersViewModel> {
        FlowersViewModelFactory(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_atlas)

        val drawerLayout = findViewById<DrawerLayout>(R.id.drawerLayoutAtl)
        val topAppBar = findViewById<MaterialToolbar>(R.id.mainAppBarAtl)
        val navView = findViewById<NavigationView>(R.id.navViewAtl)
        val recyclerView = findViewById<RecyclerView>(R.id.plantRecyclerAtl)
        val menu = navView.menu
        val ownGarden = menu.getItem(0)
        atlas = menu.getItem(1)
        val weather = menu.getItem(2)
        val logout = menu.getItem(3)

        val bundle: Bundle? = intent.extras
        val username = bundle?.getString("username")
        logged = bundle!!.getBoolean("logged")

        fun adapterOnClick(flower: InnerFlower) {
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra(FLOWER_NAME, flower.name)
            intent.putExtra("logged", logged)
            intent.putExtra("username", username)
            startActivity(intent)
        }

        val recyclerAdapter = RecyclerAdapter { flower -> adapterOnClick(flower) }

        flowersViewModel.flowersData.observe(this) {
            it?.let {
                recyclerAdapter.submitList(it as MutableList<InnerFlower>)
            }
        }

        recyclerView.adapter = recyclerAdapter

        if (logged) {
            topAppBar.title = "Atlas"

            topAppBar.setNavigationOnClickListener {
                drawerLayout.openDrawer(GravityCompat.START)
            }

            logout.setOnMenuItemClickListener {
                val i = Intent(this, LoginActivity::class.java)
                startActivity(i)
                finish()
                true
            }

            ownGarden.setOnMenuItemClickListener {
                val i = Intent(this, MainActivity::class.java)
                i.putExtra("username", username)
                startActivity(i)
                true
            }

            atlas.setOnMenuItemClickListener {
                val i = Intent(this, AtlasActivity::class.java)
                i.putExtra("username", username)
                i.putExtra("logged", true)
                startActivity(i)
                true
            }

            weather.setOnMenuItemClickListener {
                val i = Intent(this, WeatherActivity::class.java)
                i.putExtra("username", username)
                startActivity(i)
                true
            }
        } else {
            topAppBar.visibility = GONE
        }
    }


    override fun onResume() {
        super.onResume()
        atlas.isChecked = true
    }

}