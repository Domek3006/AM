package com.example.magicgarden

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.magicgarden.Modal.User
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class RegisterActivity : AppCompatActivity() {

    private var firedb = Firebase.firestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val returnToLogin = findViewById<Button>(R.id.ReturnToLogin)
        val username = findViewById<EditText>(R.id.regUsername)
        val passwd = findViewById<EditText>(R.id.regPassword)
        val passwd2 = findViewById<EditText>(R.id.regPassword2)
        val registerButton = findViewById<Button>(R.id.registerButton)

        val wrongInput = Toast.makeText(
            applicationContext,
            "Nazwa użytkownika i hasło nie mogą zawierać znaków specjalnych",
            Toast.LENGTH_LONG
        )
        val userExists =
            Toast.makeText(
                applicationContext,
                "Użytkownik o podanej nazwie już istnieje",
                Toast.LENGTH_LONG
            )
        val registered =
            Toast.makeText(applicationContext, "Zarejestrowano", Toast.LENGTH_LONG)
        val differentPasswds =
            Toast.makeText(applicationContext, "Hasła nie są takie same", Toast.LENGTH_LONG)

        registerButton.setOnClickListener {
            val users = firedb.collection("Users")
            if (username.text.toString().trim().isNotEmpty() && passwd.text.toString()
                    .trim().isNotEmpty() && passwd2.text.toString().trim().isNotEmpty()
            ) {
                if (!username.text.matches("^[a-zA-Z0-9]*$".toRegex()) || !passwd.text.matches(
                        "^[a-zA-Z0-9]*$".toRegex()
                    ) || !passwd2.text.matches("^[a-zA-Z0-9]*$".toRegex())
                ) {
                    wrongInput.show()
                } else {
                    users.document(username.text.toString()).get()
                        .addOnSuccessListener { document ->
                            if (document.data != null) {
                                userExists.show()
                            } else {
                                if (passwd.text.toString() == passwd2.text.toString()) {
                                    var user =
                                        User(username.text.toString(), passwd.text.toString())
                                    users.document(username.text.toString()).set(user)
                                        .addOnSuccessListener { registered.show() }
                                    val i = Intent(this, LoginActivity::class.java)
                                    startActivity(i)
                                } else {
                                    differentPasswds.show()
                                }
                            }
                        }
                }
            }
        }

        returnToLogin.setOnClickListener {
            super.onBackPressed()
            finish()
        }
    }
}